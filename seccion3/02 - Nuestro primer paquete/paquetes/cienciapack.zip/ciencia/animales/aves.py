#! /usr/bin/env python3

""" módulo: aves """

def Volar():
    return "¡Estoy volando!"

if __name__ == "__main__":
    print("Yo prefiero ser un módulo")
