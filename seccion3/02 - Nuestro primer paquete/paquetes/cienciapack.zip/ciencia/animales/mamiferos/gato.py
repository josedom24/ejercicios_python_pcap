#! /usr/bin/env python3

""" módulo: gato """

def Maullar():
    return "¡Miau!"

if __name__ == "__main__":
    print("Yo prefiero ser un módulo")
