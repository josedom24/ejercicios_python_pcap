#! /usr/bin/env python3

""" módulo: clima """

def Predecir():
    return "Hoy será soleado."

if __name__ == "__main__":
    print("Yo prefiero ser un módulo")
