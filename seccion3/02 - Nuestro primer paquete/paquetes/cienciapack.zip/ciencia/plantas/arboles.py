#! /usr/bin/env python3

""" módulo: arboles """

def Crecer():
    return "Estoy creciendo."

if __name__ == "__main__":
    print("Yo prefiero ser un módulo")
